This example shows how to fill %TMButtonGrid with values from database
and to use Inplace editor to update these values. At least one populated
persistent class should exist in the namespace where this example loaded.