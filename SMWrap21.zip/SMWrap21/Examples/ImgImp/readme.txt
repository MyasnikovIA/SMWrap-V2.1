This example show how to import images from local machine into database
and insert own into available project using SMWrap possibilities.